<HTML>
  <title>
    login
  </title>
  <body>
  <form method="POST" action=sign.php>
    <h1>請輸入以下資訊</h1>
    <h2>班級代號為<br>
        1:企管一甲<br>
        2:企管一乙<br>
        3:企管二甲<br>
        4:企管二乙<br>
        5:企管三甲<br>
        6:企管三乙<br>
        7:企管四甲<br>
        8:企管四乙<br>
        9:企管碩一<br>
        10:企管碩二<br>
        20:資訊一甲<br>
        21:資訊一乙<br>
        22:資訊一丙<br>
        23:資訊二甲<br>
        24:資訊二乙<br>
        25:資訊二丙<br>
    </h2>
    <form action=sign.php method="post">
      學號：<input type="text" name="id">
      姓名: <input type="text" name="name">
      班級編號: <input type="text" name="classid">
    <INPUT TYPE=submit VALUE=提交 name=on>
    </body>
</HTML>
