<HTML>
    <title>
        Login
    </title>
    <body>
        <form method="POST" action=checkaccount.php>
        <h1>請輸入學號或申請學號</h1>
        <INPUT TYPE=text name=id>
        <INPUT TYPE=submit VALUE=Login name="login">
        <INPUT TYPE=submit VALUE=SighUp name="signup">
        
    </body>
</HTML>

