<HTML>
    <body>
    <form method="POST" action=noticeaction.php>
    <h1> 警告</h1>
    <h2> 你所想退的課程為必修課</h2>
    <h2>你確定想要退嗎?</h2>
    <INPUT TYPE=submit VALUE=Yes name="YES">
    <INPUT TYPE=submit VALUE=No name="NO">
    </body>
</HTML>